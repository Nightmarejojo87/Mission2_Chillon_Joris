<h1>confirmation</h1>
<span id="alerte"><?= $msg ?></span>
<html>
    <head>

    </head>

    <body>
        <a>bravo! inscription confirmer.</a>
    </body>

</html>